package studentManagementsystem;

import java.util.Set;

public interface IStudentService {
	
	public Student postStudent();
	public Set<Student> getStudets(Set<Student> set);
	public Student getStudetById(Set<Student> set);
	public  Set<Student> putStudent(Set<Student> set);
	public Set<Student> deleteStudent(Set<Student>set);

		
}
