package studentManagementsystem;

public class Student implements Comparable<Student> {
	private int id;
	private String name;
	private int rollno;
	private double price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Student(int id, String name, int rollno, double price) {
		super();
		this.id = id;
		this.name = name;
		this.rollno = rollno;
		this.price = price;
	}
	public Student() {
		super();
	
	}
	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		if(this.id<o.getId()) {
			return -1;
		}else if(this.id>o.getId()) {
			return 1;
		}
		return 0;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", rollno=" + rollno + ", price=" + price + "]";
	}
	
	

}
