package studentManagementsystem;


import java.util.Scanner;
import java.util.TreeSet;

public class Userinterface {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		TreeSet<Student> students = new TreeSet<Student>();
		StudentService service = new StudentService();
		while (true) {
			System.out.println(
					"Enter 1 for add student\n Enter 2 for show details \n Enter 3 for get student by id\n Enter 4 for update students \n Enter 5 for delete student");
			int key = sc.nextInt();
			if (key == 1) {
				students.add(service.postStudent());

			}else if(key==2) {
				service.getStudets(students);
			}else if(key==3) {
				service.getStudetById(students);
			}else if(key==4) {
				students =(TreeSet) service.putStudent(students);
			}else if(key==5) {
				students=(TreeSet) service.deleteStudent(students);
			}
		}
	}

}
