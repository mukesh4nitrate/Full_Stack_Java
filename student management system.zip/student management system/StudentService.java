package studentManagementsystem;


import java.util.*;

public class StudentService implements IStudentService {

	Scanner sc = new Scanner(System.in);

	@Override
	public Student postStudent() {
		System.out.println("Enter the student id:");
		int id = sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the student name:");
		String name = sc.next();
		System.out.println("Enter the student rollno:");
		int rollno = sc.nextInt();
		System.out.println("Enter the fees:");
		double price = sc.nextDouble();

		Student std = new Student(id, name, rollno, price);
		return std;

	}

	@Override
	public Set<Student> getStudets(Set<Student> set) {
		System.out.println(set);
		return null;
	}

	@Override
	public Student getStudetById(Set<Student> set) {
		System.out.println("Enter the student id:");
		int id = sc.nextInt();
		for (Student std : set) {
			if (id == std.getId()) {
				return std;
			}

		}
		return null;
	}

	@Override
	public Set<Student> putStudent(Set<Student> set) {
		System.out.println("Enter the student id:");
		int id = sc.nextInt();
		sc.nextLine();
		for (Student std : set) {

			if (id == std.getId()) {

				System.out.println("Enter the student name:");
				String name = sc.next();
				System.out.println("Enter the student rollno:");
				int rollno = sc.nextInt();
				System.out.println("Enter the fees:");
				double price = sc.nextDouble();
				std.setName(name);
				std.setId(id);
				std.setRollno(rollno);
				std.setPrice(price);
				

				return set;

			}

		}
		return set;
	}

	@Override
	public Set<Student> deleteStudent(Set<Student> set) {
		System.out.println("Enter the student id for delete:");
		int id =sc.nextInt();
		sc.next();
		for(Student std: set) {
			if(id==std.getId());
			return set;
		}
		return set;
	}

}
